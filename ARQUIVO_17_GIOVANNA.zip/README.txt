ARQUIVO 17 — GIOVANNA
Abra index.html no Google Chrome.
O jogo funciona offline e salva o progresso no localStorage.
Para publicar na internet, envie esta pasta para qualquer hospedagem estática (GitHub Pages, Netlify, Vercel etc.).
